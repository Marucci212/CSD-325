from django.contrib import admin
from django.urls import path
from sampson import views  # Make sure this matches your app name

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),  # Homepage now uses your custom view
]
